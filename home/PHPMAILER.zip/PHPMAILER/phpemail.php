<?php
	require 'sendmail.php';
	$subject = "Introduction";
	$name = $_GET['name'];
	$contact = $_GET['contact'];
	$emailAddr=$_GET['emailAddr'];
	$dob=$_GET['dob'];
	$gender=$_GET['gender'];
	$bloodgroup=$_GET['bloodgroup'];
	$fathersname=$_GET['fathersname'];
	$spousename=$_GET['spousename'];
	$weddingdate=$_GET['weddingdate'];
	$numberofchildren=$_GET['numberofchildren'];
	$house=$_GET['house'];
	$street=$_GET['street'];
	$landmark=$_GET['landmark'];
	$area=$_GET['area'];
	$town=$_GET['town'];
	$postoffice=$_GET['postoffice'];
	$district=$_GET['district'];
	$presentstate=$_GET['presentstate'];
	$presentpincode=$_GET['presentpincode'];
	$nativewadi=$_GET['nativewadi'];
	$nativegaon=$_GET['nativegaon'];
	$nativetaluka=$_GET['nativetaluka'];
	$nativepostoffice=$_GET['nativepostoffice'];
	$nativedistrict=$_GET['nativedistrict'];
	$nativestate=$_GET['nativestate'];
	$vpincode=$_GET['vpincode'];
	$qualification=$_GET['qualification'];
	$profession=$_GET['profession'];
	$activities=$_GET['activities'];
	$entrepreneurialactivities=$_GET['entrepreneurialactivities'];
	$matrimonialservices=$_GET['matrimonialservices'];
	$investpatpedhi=$_GET['investpatpedhi'];
	$interestedpatpedhi=$_GET['interestedpatpedhi'];
	
	
	
	
	
	$body = "<html>
	<head>
	<style>
	.tablecss .label
	{background-color:#b5b6be;text-align:right;margin:0;padding:0.5em 0.9em;font-weight:bold;} 
	.tablecss .labelvalue{margin:0;padding:0.5em;}
	.tablecss {border:5px solid grey;margin:0;padding:0;border-collapse: collapse;font-size:14px;font-family:Calibri;}
	</style>
	</head>
	<body>
	<table border=1 class=\"tablecss\">
	<tr>
	<td class=\"label\">NAME</td>
	<td class=\"labelvalue\">".$name."</td>

	</tr>
	<tr>
	<td class=\"label\">CONTACT</td>
	<td class=\"labelvalue\">".$contact."</td>
	
	</tr>
	<tr>
	<td class=\"label\">EMAIL</td>
	<td class=\"labelvalue\">".$emailAddr."</td>
	
	</tr>
	<tr>
	<td class=\"label\">DATE OF BIRTH</td>
	<td class=\"labelvalue\">".$dob."</td>
	
	</tr>
	<tr>
	<td class=\"label\">GENDER</td>
	<td class=\"labelvalue\">".$gender."</td>

	</tr>
	<tr>
	<td class=\"label\">BLOOD GROUP</td>
	<td class=\"labelvalue\">".$bloodgroup."</td>
	
	</tr>
	<tr>
	<td class=\"label\">FATHER'S NAME</td>
	<td class=\"labelvalue\">".$fathersname."</td>
	
	</tr>
	<tr>
	<td class=\"label\">SPOUSE NAME</td>
	<td class=\"labelvalue\">".$spousename."</td>
	
	</tr>
	<tr>
	<td class=\"label\">WEDDING DATE</td>
	<td class=\"labelvalue\">".$weddingdate."</td>
	
	</tr>
	<tr>
	<td class=\"label\">NUMBER OF CHILDREN</td>
	<td class=\"labelvalue\">".$numberofchildren."</td>

	</tr>
	<tr>
	<td class=\"label\">PRESENT ADDRESS</td>
	<td class=\"labelvalue\">".$house."</td>
	<td class=\"labelvalue\">".$street."</td>
	<td class=\"labelvalue\">".$landmark."</td>
	<td class=\"labelvalue\">".$area."</td>
	<td class=\"labelvalue\">".$town."</td>
	<td class=\"labelvalue\">".$postoffice."</td>
	<td class=\"labelvalue\">".$district."</td>
	<td class=\"labelvalue\">".$presentstate."</td>
	<td class=\"labelvalue\">".$presentpincode."</td>
	</tr>
	
	
	<tr>
	<td class=\"label\">VILLAGE NAME</td>
	<td class=\"labelvalue\">".$nativewadi."</td>
	<td class=\"labelvalue\">".$nativegaon."</td>
	<td class=\"labelvalue\">".$nativetaluka."</td>
	<td class=\"labelvalue\">".$nativepostoffice."</td>
	<td class=\"labelvalue\">".$nativedistrict."</td>
	<td class=\"labelvalue\">".$nativestate."</td>
	</tr>
	<tr>
	<td class=\"label\">VILLAGE PINCODE</td>
	<td class=\"labelvalue\">".$vpincode."</td>
	
	</tr>
	<tr>
	<td class=\"label\">QUALIFICATION</td>
	<td class=\"labelvalue\">".$qualification."</td>
	
	</tr>
	<tr>
	<td class=\"label\">PROFESSION</td>
	<td class=\"labelvalue\">".$profession."</td>
	
	</tr>
	<tr>
	<td class=\"label\">PROFESSION</td>
	<td class=\"labelvalue\">".$profession."</td>
	
	</tr>
	<tr>
	<td class=\"label\">WISH TO HELP OR CONTRIBUTE IN SAMAJ ACTIVITIES</td>
	<td class=\"labelvalue\">".$activities."</td>
	
	
	</tr>
	<tr>
	<td class=\"label\">INTERESTED IN ENTERPRENEURIAL ACTIVITIES</td>
	<td class=\"labelvalue\">".$entrepreneurialactivities."</td>

	</tr>
	<tr>
	<td class=\"label\">NEED MATRIMONIAL SERVICES</td>
	<td class=\"labelvalue\">".$matrimonialservices."</td>
	
	</tr>
	<tr>
	<td class=\"label\">INTERESTED TO INVEST & CONTRIBUTE FOR PATPEDHI</td>
	<td class=\"labelvalue\">".$investpatpedhi."</td>
	
	</tr>
	<tr>
	<td class=\"label\">WILLING TO WORK IF INTERESTED IN PATPEDHI</td>
	<td class=\"labelvalue\">".$interestedpatpedhi."</td>
	
	</tr>
	</table>
	</body>
	</html>";

	sendEmail($subject, $body, $emailAddr);
?> 