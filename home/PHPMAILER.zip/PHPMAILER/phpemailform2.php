<?php
	require 'sendmailform2.php';
	$subject = "ENQUIRY";
	$fullname = $_GET['fullname'];
	$gender=$_GET['gender'];
	$age=$_GET['age'];
	$mobile=$_GET['mobile'];
	$village=$_GET['village'];
	$emailAddr=$_GET['emailAddr'];
	$message=$_GET['message'];
	
	
	
	
	
	
	
	$body = "<html>
	<head>
	<style>
	.tablecss .label
	{background-color:#b5b6be;text-align:right;margin:0;padding:0.5em 0.9em;font-weight:bold;} 
	.tablecss .labelvalue{margin:0;padding:0.5em;}
	.tablecss {border:5px solid grey;margin:0;padding:0;border-collapse: collapse;font-size:14px;font-family:Calibri;}
	</style>
	</head>
	<body>
	<table border=1 class=\"tablecss\">
	<tr>
	<td class=\"label\">FULLNAME</td>
	<td class=\"labelvalue\">".$fullname."</td>
	</tr>
	
	<tr>
	<td class=\"label\">CONTACT</td>
	<td class=\"labelvalue\">".$mobile."</td>
	</tr>
	
	<tr>
	<td class=\"label\">EMAIL ADDRESS</td>
	<td class=\"labelvalue\">".$emailAddr."</td>
	</tr>
	<tr>
	<td class=\"label\">MESSAGE</td>
	<td class=\"labelvalue\">".$message."</td>
	</tr>
	</table>
	</body>
	</html>";

	sendEmail($subject, $body,$emailAddr);
?> 